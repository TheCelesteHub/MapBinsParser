local bird = {}
bird.name = "BrassHelper/HoldableBird"
bird.texture = "characters/bird/Hover04"
bird.depth = -1
bird.placements = {
    name = "normal",
    data = {
        tutorial = false,
    }
}

return bird