return {
    name = "BrassHelper/HitboxIndicatorController", 
    placements = {name = "normal"},
    texture = "objects/BrassHelper/hitbox_indicator_controller",
}