return {
    name = "BrassHelper/CassetteHiccupController",
    texture = "objects/BrassHelper/cassette_hiccup_controller",
    placements = {
        name = "normal"
    },
}