local drawableSprite = require("structs.drawable_sprite")
local drawableLine = require("structs.drawable_line")
local drawing = require("utils.drawing")

local hold = {}
hold.name = "BrassHelper/JellyHolder"

hold.placements = {
    name = "normal",
}

function hold.sprite(room, entity)
    local x, y = entity.x or 0, entity.y or 0
    local points = drawing.getSimpleCurve({x - 11, y - 1}, {x + 11, y - 1}, {x - 0, y - 6})
    local lineSprites = drawableLine.fromPoints(points):getDrawableSprite()

    return lineSprites
end

return hold