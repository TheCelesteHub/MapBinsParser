local drawableSprite = require("structs.drawable_sprite")

local cordable = {}

cordable.name = "BrassHelper/CoreHoldable"
cordable.depth = 100

local offsetY = -10
local texture = "characters/theoCrystal/idle00"

function cordable.sprite(room, entity)
    local sprite = drawableSprite.fromTexture(texture, entity)

    sprite.y += offsetY

    return sprite
end

cordable.placements = {
    name = "cordable",
    data = {
        flag = "",
        bubble = false,
    }
}

return cordable