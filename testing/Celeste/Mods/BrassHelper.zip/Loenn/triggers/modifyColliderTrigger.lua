local trigger = {}

trigger.name = "BrassHelper/ModifyColliderTrigger"

trigger.placements = {
    name = "normal",
    data = {
        colliderX = 0,
        colliderY = 0,
        colliderWidth = 0,
        colliderHeight = 0,
        entityType = "",
        fieldName = "",
        despawnMode = "Never",
    },
}

trigger.fieldOrder = {
    "x",
    "y",
    "width",
    "height",
    "colliderX",
    "colliderY",
    "colliderWidth",
    "colliderHeight",
    "entityType",
    "fieldName",
    "despawnMode",
}
trigger.fieldInformation = {
    despawnMode = {options = {"Never", "On first use", "On level load"}, editable = false,},
}
--[[
jautils.createPlacementsPreserveOrder(trigger, "Modify Collider Trigger", {
    {"width", 18},
    {"height", 18},
    {"colliderX", 0},
    {"colliderY", 0},
    {"colliderWidth", 0},
    {"colliderHeight", 0},
    {"entityType", ""},
    {"despawnMode", "Never", {"Never", "On first use", "On level load"}},
})
--]]
return trigger